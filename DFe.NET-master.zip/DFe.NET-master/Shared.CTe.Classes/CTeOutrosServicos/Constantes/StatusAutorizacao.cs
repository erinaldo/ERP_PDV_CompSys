﻿namespace CTe.CTeOSDocumento.CTe.Constantes
{
    public enum StatusAutorizacao
    {
        Autorizado = 100,
        Cancelada = 101,
        Denegada = 110,
        DenegadoEmitente = 301,
        Denegado205 = 205
    }
}