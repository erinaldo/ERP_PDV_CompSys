﻿using CTe.Classes.Informacoes.infCTeNormal.infCteSubs;

namespace CTe.CTeOSDocumento.CTe.CTeOS.Informacoes.InfCTeNormal
{
    public class infCteSubOs
    {
        public string chCte { get; set; }
        
        public string refCteAnu { get; set; }

        public tomaICMS tomaICMS { get; set; }
    }
}