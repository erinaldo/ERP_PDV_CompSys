﻿using CTe.Classes.Informacoes.Tipos;

namespace CTe.CTeOSDocumento.CTe.CTeOS.Informacoes.InfCTeNormal
{
    public class segOs
    {
        public respSeg respSeg { get; set; }

        public string xSeg { get; set; }

        public string nApol { get; set; }
    }
}