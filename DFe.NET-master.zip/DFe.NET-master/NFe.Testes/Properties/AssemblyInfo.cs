using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("NFe.Testes")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("NFe.Testes")]
[assembly: AssemblyCopyright("Copyright ©  2017-2018")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("3e44ea28-96ae-4fac-9e38-adc2e12930f1")]

// [assembly: AssemblyVersion("1.0.0.772")]
[assembly: AssemblyVersion("1.0.0.772")]
[assembly: AssemblyFileVersion("1.0.0.772")]
