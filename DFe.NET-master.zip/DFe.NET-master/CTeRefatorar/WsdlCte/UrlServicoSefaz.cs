﻿namespace FusionCore.DFe.WsdlCte
{
    public class UrlServicoSefaz
    {
        public string CteRecepcao { get; set; }
        public string CteRetRecepcao { get; set; }
        public string CteInutilizacao { get; set; }
        public string CteStatusServico { get; set; }
        public string CteRecepcaoEvento { get; set; }
    }
}