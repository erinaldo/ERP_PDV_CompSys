﻿using System.Xml.Serialization;

namespace FusionCore.DFe.XmlCte
{
    public enum FusionIndicadorRecebedorCTe
    {
        [XmlEnum("0")]
        Sim,

        [XmlEnum("1")]
        Nao
    }
}