﻿using System.Xml.Serialization;

namespace FusionCore.DFe.XmlCte
{
    public enum FusionTipoAmbienteCTe
    {
        [XmlEnum("1")]
        Producao = 1,

        [XmlEnum("2")]
        Homologacao = 2
    }
}