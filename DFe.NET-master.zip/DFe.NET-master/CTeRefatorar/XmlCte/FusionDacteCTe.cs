﻿using System.Xml.Serialization;

namespace FusionCore.DFe.XmlCte
{
    public enum FusionDacteCTe
    {
        [XmlEnum("1")]
        Retrato = 1,

        [XmlEnum("2")]
        Paisagem = 2
    }
}