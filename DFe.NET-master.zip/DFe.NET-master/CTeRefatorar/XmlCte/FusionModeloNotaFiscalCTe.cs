﻿using System.Xml.Serialization;

namespace FusionCore.DFe.XmlCte
{
    public enum FusionModeloNotaFiscalCTe
    {
        [XmlEnum("01")]
        NFModelo011AeAvulsa = 01,

        [XmlEnum("04")]
        NFdeProdutor = 04
    }
}