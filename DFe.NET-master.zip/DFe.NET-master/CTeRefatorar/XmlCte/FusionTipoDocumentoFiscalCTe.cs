﻿using System.Xml.Serialization;

namespace FusionCore.DFe.XmlCte
{
    public enum FusionTipoDocumentoFiscalCTe
    {
        [XmlEnum("57")]
        CTe = 57
    }
}